<?php

class ForumLastPostPrefix_Extend_NodeHandler_Forum extends XFCP_ForumLastPostPrefix_Extend_NodeHandler_Forum
{
    // Remember above this same function? Now we are overwriting it to add a custom
    // join option
    public function getExtraDataForNodes(array $nodeIds)
    {
        $userId = XenForo_Visitor::getUserId(); // TODO: ideally this should be passed in
        $forumFetchOptions = array(
            'readUserId' => $userId,
            /* Below we say: 'do a join to the post table, and then to the xf_thread table and return
             * back the prefix_id'. This may appear more simple then that, but actually the whole interpretation
             * is inside the Forum Model. Here we just pass an option so later we can identify what we
             * want to join. */
            'last_post' => true
        );

        // Return the nodes with the forumFetchOptions we customized!
        return $this->_getForumModel()->getExtraForumDataForNodes($nodeIds, $forumFetchOptions);
    }

    /**
     * Gets the pushable data for a forum-like node. Most nodes, including
     * categories and forums, will fall into this category, provided the
     * key names match.
     *
     * This function does not check any permissions.
     *
     * @param array $node Info about the current node
     * @param array $childPushable List of pushable data for child nodes ([node id] => info)
     *
     * @return array Key-value pairs of pushable data
     */
    protected function _getForumLikePushableData(array $node, array $childPushable)
    {
        $newPushable = array(
            'discussion_count' => (isset($node['discussion_count']) ? $node['discussion_count'] : 0),
            'message_count' => (isset($node['message_count']) ? $node['message_count'] : 0),
            'hasNew' => (isset($node['hasNew']) ? $node['hasNew'] : false),
            'prefix_id' => (isset($node['prefix_id']) ? $node['prefix_id'] : false)
        );

        if ($newPushable['discussion_count'] && !XenForo_Visitor::getUserId())
        {
            $newPushable['hasNew'] = true;
        }

        if (!empty($node['last_post_date']))
        {
            $newPushable['last_post_id'] = $node['last_post_id'];
            $newPushable['last_post_date'] = $node['last_post_date'];
            $newPushable['last_post_user_id'] = $node['last_post_user_id'];
            $newPushable['last_post_username'] = $node['last_post_username'];
            $newPushable['last_thread_title'] = XenForo_Helper_String::censorString($node['last_thread_title']);
        }

        return $this->_compileForumLikePushableData($newPushable, $childPushable);
    }

    /**
     * Takes collected pushable data and compiles it with the child pushable data into a final value.
     *
     * @param array $newPushable
     * @param array $childPushable
     *
     * @return array
     */
    protected function _compileForumLikePushableData(array $newPushable, array $childPushable)
    {
        $newPushable = array_merge(array(
            'discussion_count' => 0,
            'message_count' => 0,
            'hasNew' => false,
            'privateInfo' => false,
            'childCount' => 0,
            'last_post_id' => 0,
            'last_post_date' => 0,
            'last_post_user_id' => 0,
            'last_post_username' => '',
            'last_thread_title' => ''
        ), $newPushable);

        foreach ($childPushable AS $childData)
        {
            if (!empty($childData['discussion_count']))
            {
                $newPushable['discussion_count'] += $childData['discussion_count'];
            }

            if (!empty($childData['message_count']))
            {
                $newPushable['message_count'] += $childData['message_count'];
            }

            if (!empty($childData['last_post_date']) && $childData['last_post_date'] > $newPushable['last_post_date'])
            {
                $newPushable['last_post_id'] = $childData['last_post_id'];
                $newPushable['last_post_date'] = $childData['last_post_date'];
                $newPushable['last_post_user_id'] = $childData['last_post_user_id'];
                $newPushable['last_post_username'] = $childData['last_post_username'];
                $newPushable['last_thread_title'] = $childData['last_thread_title'];
                $newPushable['prefix_id'] = isset($childData['prefix_id']) ? $childData['prefix_id'] : false;
            }

            if (!empty($childData['hasNew']))
            {
                // one child has new stuff
                $newPushable['hasNew'] = true;
            }

            $newPushable['childCount'] += 1 + (!empty($childData['childCount']) ? $childData['childCount'] : 0);
        }

        $newPushable['lastPost'] = array(
            'post_id'   => $newPushable['last_post_id'],
            'date'      => $newPushable['last_post_date'],
            'user_id'   => $newPushable['last_post_user_id'],
            'username'  => $newPushable['last_post_username'],
            'title'     => $newPushable['last_thread_title']
        );

        return $newPushable;
    }
}
