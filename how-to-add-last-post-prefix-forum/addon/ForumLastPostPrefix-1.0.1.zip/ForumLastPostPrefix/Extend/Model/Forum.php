<?php
class ForumLastPostPrefix_Extend_Model_Forum extends XFCP_ForumLastPostPrefix_Extend_Model_Forum
{
    /*
     * This is the same function of XenForo. But since here we don't want to overwrite, we will
     * call the parent first, get the contents and then later apply our join to another table.
     */

    public function prepareForumJoinOptions(array $fetchOptions)
    {
        /* The line below return an array with two keys: 'selectFields' and 'joinTables'.
         * One of them means: "which fields should I select to this forum?" The another means:
         * "Which tables should I join to get some extra data to this forum?"
         */
        $parent = parent::prepareForumJoinOptions($fetchOptions);

        // If we set that we want to fetch last_post info...
        if (isset($fetchOptions['last_post'])) {
            $parent['selectFields'] .= ', post.thread_id, thread.prefix_id ';
            $parent['joinTables'] .= ' INNER JOIN xf_post AS post ON (forum.last_post_id = post.post_id) INNER JOIN xf_thread AS thread ON (thread.thread_id = post.thread_id)';
        }

        return $parent;
    }
}
