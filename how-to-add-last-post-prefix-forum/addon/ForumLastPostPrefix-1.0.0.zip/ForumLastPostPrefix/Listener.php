<?php

/**
 * This is the Listener. It will extend the classes below.
 */
class ForumLastPostPrefix_Listener
{
    /**
     * Extend the XenForo_NodeHandler_Forum class.
     */
    public static function extendNodeHandlerForum($class, array &$extend)
    {
        // This is the name of our class. The path to this file will be:
        // ForumLastPostPrefix/Extend/NodeHandler/Forum
        $extend[] = 'ForumLastPostPrefix_Extend_NodeHandler_Forum';
    }

    /**
     * Extend the XenForo_Model_Forum class
     */
    public static function extendModelForum($class, array &$extend)
    {
        // This is the name of our class. The path to this file will be:
        // ForumLastPostPrefix/Extend/Model/Forum
        $extend[] = 'ForumLastPostPrefix_Extend_Model_Forum';
    }
}
