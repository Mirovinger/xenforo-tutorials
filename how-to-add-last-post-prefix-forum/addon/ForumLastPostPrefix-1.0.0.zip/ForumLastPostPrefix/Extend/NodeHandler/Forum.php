<?php

class ForumLastPostPrefix_Extend_NodeHandler_Forum extends XFCP_ForumLastPostPrefix_Extend_NodeHandler_Forum
{
    // Remember above this same function? Now we are overwriting it to add a custom
    // join option
    public function getExtraDataForNodes(array $nodeIds)
    {
        $userId = XenForo_Visitor::getUserId(); // TODO: ideally this should be passed in
        $forumFetchOptions = array(
            'readUserId' => $userId,
            /* Below we say: 'do a join to the post table, and then to the xf_thread table and return
             * back the prefix_id'. This may appear more simple then that, but actually the whole interpretation
             * is inside the Forum Model. Here we just pass an option so later we can identify what we
             * want to join. */
            'last_post' => true
        );

        // Return the nodes with the forumFetchOptions we customized!
        return $this->_getForumModel()->getExtraForumDataForNodes($nodeIds, $forumFetchOptions);
    }
}
